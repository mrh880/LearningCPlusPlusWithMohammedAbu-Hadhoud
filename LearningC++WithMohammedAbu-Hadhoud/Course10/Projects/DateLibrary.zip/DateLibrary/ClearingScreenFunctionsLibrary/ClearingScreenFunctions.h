#pragma once

// This function will clear the screen for most modern terminal
// -----------------------------------------------------------------------------
void ClearScreen();
// -----------------------------------------------------------------------------
