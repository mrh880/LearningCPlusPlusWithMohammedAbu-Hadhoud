#pragma once

enum enDateCompareDates
{
    Before = -1,
    Equal = 0,
    After = 1
};